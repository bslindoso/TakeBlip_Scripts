//AtualizaTelefoneWpp
function run(identificador) {
    var telefoneUsuario = identificador.split("@")[0];
    return telefoneUsuario;
    }