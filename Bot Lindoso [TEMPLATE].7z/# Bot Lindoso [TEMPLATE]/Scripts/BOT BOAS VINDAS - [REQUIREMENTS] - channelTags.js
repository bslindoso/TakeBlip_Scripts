{{resource.FunctionGetMenu}}
function run(platform) {
  return channelTags(platform);
}